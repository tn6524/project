package portfolio;
//DB
import java.sql.*;
public class dbconnect {	
	
	protected Connection dbcon2() throws ClassNotFoundException, SQLException{
		String dbdriver = "com.mysql.jdbc.Driver";
		String url= "jdbc:mysql://localhost/rlawlstn9812";
		String user="rlawlstn9812";
		String userpw ="mc69!54@23";
		Class.forName(dbdriver);	
		Connection con = DriverManager.getConnection(url,user,userpw);
		return con;
	}

}